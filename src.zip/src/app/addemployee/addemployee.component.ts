import { Component } from '@angular/core';

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent {
  newEmployeeName!: string;

  addEmployee() {
    // Implement logic to add a new employee using the REST API or service
    console.log('Adding employee:', this.newEmployeeName);
  }
}
