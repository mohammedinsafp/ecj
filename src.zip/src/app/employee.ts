export class Employee {
    id!:number;
    name!:string;
}
